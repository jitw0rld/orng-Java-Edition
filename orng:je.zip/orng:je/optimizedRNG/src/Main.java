import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random r = new Random();
        int randint = r.nextInt();

        System.out.println("Your random number is: " + randint);

        while (true){
            ; // optimize gpu cpu :thumbsup:
        }
    }
}
